Das Programm kann mit java ZufallszahlenVisualisierung gestartet werden.

Um einen anderen Zufallsgenerator zu verwenden, übergibt man in der main-Methode einfach eins der Arrays test_1, test_2 oder test_3 dem Konstruktor übergeben (Z. 167).
Danach muss das Programm neu übersetzt werden.

Am Anfang wird der in c) geforderte Generator übergeben.
