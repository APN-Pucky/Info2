import java.util.ArrayList;

/**
 * 
 * @author Alexander Neuwirth
 * @author Leonhard Segger
 * @author Jonathan Sigrist
 *
 */
public class Aufgabe29 {

	/**
	 * Hauptmethode: Berechnet alle moeglichen Paare eines Arrays mit a+b = 7
	 * 
	 * @param args
	 *            Konsoleneingaben
	 */
	public static void main(String[] args) {
		int[][] a = computePairsForSum(new int[] { 1, 2, -1, -2, -3, -5, -67, -82, -16, 3, 4, 5, 56, 7, 8, 89, 0, 98, 7,
				665, 65, 433, 23, 221 }, 7);
		System.out.println("Paare:");
		for (int i = 0; i < a.length; i++) {
			System.out.println("(" + a[i][0] + ", " + a[i][1] + ")");
		}
	}

	/**
	 * Laufzeit Quicksort O(n*log(n)) und N-fach binaer Suchen auch O(n*log(n))
	 * macht zusammen O(n*log(n))
	 * 
	 * @param values
	 *            zu durchsuchendes Array
	 * @param sum
	 *            zu suchende Summe
	 * @return Array mit allen Paaren (a, b) mit a+b = sum
	 */
	public static int[][] computePairsForSum(int[] values, int sum) {
		ArrayList<int[]> list = new ArrayList<int[]>();
		quickSort(values, 0, values.length - 1);
		for (int i = values.length - 1; i >= 0; i--)// n
		{
			if (contains(values, 0, i, sum - values[i]))
				list.add(new int[] { sum - values[i], values[i] });

		}
		return list.toArray(new int[][] {});
	}

	/**
	 * Sucht in einem Array in einem Intervall binaer nach einem Wert
	 * 
	 * @param a
	 *            zu durchsuchendes Array
	 * @param begin
	 *            Anfangsindex
	 * @param end
	 *            Endindex
	 * @param val
	 *            zu suchender Wert
	 * @return true falls Wert gefunden, false falls nicht gefunden
	 */
	private static boolean contains(int[] a, int begin, int end, int val) {
		if (a[(begin + end) / 2] == val) {
			return true;
		} else {
			if (begin >= end)
				return false;

			if (a[(begin + end) / 2] > val) {
				return contains(a, begin, (begin + end) / 2 - 1, val);
			} else if (a[(begin + end) / 2] < val) {
				return contains(a, (begin + end) / 2 + 1, end, val);
			}
		}
		// dead code :/
		return false;
	}

	/**
	 * Sortiert ein Array nach dem Quicksort-Algorithmus
	 * 
	 * @param a
	 *            Array
	 * @param l
	 *            linke Seite
	 * @param r
	 *            rechte Seite
	 */
	private static void quickSort(int[] a, int l, int r) {
		// Pivot Mitte
		int m = a[(l + r) / 2];
		int i = l;
		int j = r;
		while (i <= j) {
			for (; a[i] < m; i++)
				;
			for (; m < a[j]; j--)
				;
			if (i <= j) {
				swap(a, i, j);

				i++;
				j--;
			}
		}
		if (l < j)
			quickSort(a, l, j);
		if (i < r)
			quickSort(a, i, r);
	}

	/**
	 * Tauscht zwei Werte miteinander
	 * 
	 * @param a
	 *            Array
	 * @param b
	 *            Wert 1
	 * @param c
	 *            Wert 2
	 */
	private static void swap(int[] a, int b, int c) {
		int tmp = a[b];
		a[b] = a[c];
		a[c] = tmp;
	}
}
