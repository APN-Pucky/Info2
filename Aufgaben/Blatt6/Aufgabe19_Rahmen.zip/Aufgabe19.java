// file "Aufgabe19.java"

import java.awt.Color;

/**
 * Rahmen zur Aufgabe 19.
 * Verwendet ein (privates) Visualizer-Objekt, um die
 * Animation der Sortieralgorithmen darzustellen.
 * 
 * @author    Daniel Ehlke, edited by Aaron Scherzinger
 * 
 * @see       Visualizer
 */
public class Aufgabe19 {
    
    // statisches Attribut fuer Visualizer-Objekt (fuer die Animation noetig)
    private static Visualizer v = null;
    
    /**
     * Fuellt ein Eingabearray mit Zufallszahlen.
     * @param a das Eingabearray
     */
    private static void fillArray(int[] a) {
        java.util.Random r = new java.util.Random();
        for (int i=0; i<a.length; i++) {
            a[i] = r.nextInt(a.length) + 1; 
            
            // dafuer sorgen, dass jeder Wert von 1 bis a.length
            // nur genau einmal im Array vorkommt
            for (int k=0; k<i; k++) {
                if (a[i] == a[k]) {
                    i--;
                    break;
                }
            }
        }
    }
    
    /**
     * Zaehlt einen Countdown herunter und zeigt diesen auch an.
     * Erwartet, dass das Visualizer-Objekt v gesetzt ist.
     * @param seconds Laenge des Countdowns.
     */
    private static void countdown(int seconds) {
        if (v == null)
            throw new IllegalStateException("Visualizer-Objekt v "
                                            +"existiert nicht!");
        for (int i=seconds; i>0; i--) {
            v.setLegend("Start in "+i+" Sekunden ...");
            v.repaint();
            v.sleepRealtime(1000);
        }
    }
    
    /**
     * Das Hauptprogramm fuer die Aufgabe 19
     */
    public static void main(String[] args) {

        int[] a = new int[100];// Erstelle Array a 
        fillArray(a);          // Fuelle das Array mit Zufallszahlen
        
        v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
                               // die Animation wird damit moeglich
        
        countdown(3);          // es spannend machen ;-)
        visualBubbleSort(a);   // visuell sortieren
        v.sleepRealtime(5000); // 5 Sekunden warten
        
        // Zuruecksetzen fuer den naechsten Sortier-Algorithmus
        v.reset();    // grafischen Visualizer zuruecksetzen
        fillArray(a); // Array mit neuen Zahlen fuellen
        v.setData(a); // Array-Daten des Visualizers setzen
        v.repaint();  // Neuzeichnen des Fensters
        
        countdown(3);
        visualBubbleSort(a); // bzw. eigentlich visualSelectionSort(a);
        
        // ... (hier weitere Sortieralgorithmen aufrufen)
    }
    
    /**
     * Sortiert ein int-Array mit dem Bubble-Sort Algorithmus
     * (Code siehe Aufgabe 20) und visualisiert dies mit Hilfe
     * eines (statischen) Visualizer-Objekts v, welches existieren muss.
     * 
     * @param a   das zu sortierende Array
     * 
     * @throws IllegalStateException falls das Visualizer-Objekt nicht existiert
     */
    public static void visualBubbleSort(int[] a) {
        if (v == null)
            throw new IllegalStateException("Visualizer-Objekt v "
                                            +"existiert nicht!");
        v.setLegend("Bubble Sort");
        int hilf = 0;
        boolean vertauscht = false;
        int run = 0;
        do {
            run += 1;
            vertauscht = false;
            for (int i=0; i<a.length-run; i++) {
                v.setLabel(i, "i");
                v.setHighlight(i, v.VERTICAL_HIGHLIGHT);
                if (a[i] > a[i+1]) {
                    hilf = a[i];
                    a[i] = a[i+1];
                    a[i+1] = hilf;
                    vertauscht = true;
                }
                v.setColor(i, Color.RED);
                v.setColor(i+1,Color.ORANGE);
                v.setData(a);
                v.repaint(); // alles neuzeichnen
                v.sleep(2);  // und warten
                v.setLabel(i, "");
                v.setHighlight(i, v.NO_HIGHLIGHT);
                if (i == a.length-run-1)
                    v.setColor(i+1, Color.BLACK);
            }
        } while (vertauscht);
        v.setData(a);
        v.setLegend("Bubble Sort (terminiert)");
        v.repaint();
    }

    public static void visualInsertionSort(int[] a) {
        // TODO!
    }


    public static void visualSelectionSort(int[] a) {
        // TODO!
    }


    public static void visualMergeSort(int[] a) {
        // TODO!
    }
    
} // class Aufgabe19
