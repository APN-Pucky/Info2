Das Java Programm Aufgabe4 kann mit "java Aufgabe4" in der Konsole gestartet werden.

Als gültige Parameter sind erlaubt:
-h oder --help		Gibt einen kurzen Hilfetext in der Konsole aus.
-i oder --interactive	Der Benutzer wird nach Eingaben gefrage, welche zur Berechnung genutzt werden.
[Zahl1] [Zahl2]		Führt die Berechnung für diese beiden Zahlen aus. Falls keine gültigen Zahlen übergeben werden, wird eine Errormeldung ausgegeben.

