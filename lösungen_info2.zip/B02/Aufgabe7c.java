public class Aufgabe7c {

/** 
 * Modulare Berechnung von Fibonacci-Zahlen.
 * Liefert ein Tripel der Reste bzgl. der Moduli 999, 1000 und 1001.
 *
 * @param n das n-te Folgeglied wird berechnet (n > 0 erwartet)
 * @return n-te Fibonaccizahl als Tripel-Darstellung
 * @throws IllegalArgumentException wenn nicht n > 0 eingegeben wird
 */
public short[] modularFib(short n) throws IllegalArgumentException {

    // Fibonacci-Zahlen 0 und 1 als Tripel darstellen
    short[] p = {0,0,0};         
    short[] q = {1,1,1};          

    // die Moduli
    short[] m = {999, 1000, 1001};
   
    if (n < 0)  // wenn n < 0: Fehler
        throw new IllegalArgumentException("n > 0 required"); 
    else if (n == 0)  // Fib(0) direkt zurueckgeben
        return p;
    else if (n == 1)  // Fib(1) direkt zurueckgeben 
        return q; 
    else {  
        // für n > 1 wird die Fibonacci-Zahl iterativ berechnet
        short[] r = new short[3];  // iterativ neu berechnete Fibonacci-Zahl
        for (int i=1; i<n; i++) {
            // naechste Fib-Zahl r auf Basis der beiden Vorgaenger berechnen
            for (int j=0; j<3; j++)
                r[j] = (short) ((p[j] + q[j]) % m[j]);
            // die Vorgaenger verschieben
            for (int j=0; j<3; j++) {
                p[j] = q[j];
                q[j] = r[j];
            }
        }
        return r;
    }
}

/**
 * Kleiner Test der modularen Fibonacci-Berechnung.
 */
public static void main(String[] args) {
    // Teste die Werte { -1, 0, 1, 2, 5, 20, 40 }
    short[] testValues = { -1, 0, 1, 2, 5, 20, 40 };
    Aufgabe7c calc = new Aufgabe7c();

    for (int i=0; i < 7; i++) {
        System.out.println("Ergebnis von modularFib(" + testValues[i] + "): ");
        try {
            short[] result = calc.modularFib(testValues[i]);
            System.out.println("(" + result[0] + ", " + result[1] + ", " + result[2] + ") \n" );
        }
        catch (IllegalArgumentException e) {
            System.out.println(e.getMessage() + "\n");
        }
    }
}

}
