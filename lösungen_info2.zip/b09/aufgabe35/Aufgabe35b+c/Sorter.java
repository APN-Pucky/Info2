//
//  Sorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//



public abstract class Sorter implements Runnable {

    // Anzahl der Vertauschungen
    protected int swaps;
    //Anzahl der Vergleiche
    protected int compares;
    // Das zu sortierende Array
    protected int[] array;
    // Ein Thread - allerdings bisher ungenutzt
    protected Thread runner;

    // Wrappermethode um die Vertauschungen hochzuzaehlen
    protected void incSwaps()
    {
        swaps++;
    }

    //Wrappermethode um die Vergleiche hochzuzaehlen
    protected void incCompares()
    {
        compares++;
    }

    // Getter-Methode fuer Vertauschungen
    public int getSwaps()
    {
        return swaps;
    }


    //Getter-Methode fuer Vergleiche
    public int getCompares()
    {
        return compares;
    }

    //Getter.Methode fuer das Array
    public int[] getArray()
    {
        return array;
    }

    //Abstrakte methode sort, die den zugriff fuer alle Subklassen vereinheitlicht
    public abstract void sort();

    //Vertauschmethode, die in alles Sortierverfahren ben�tigt wird
    public int[] swap(int[] a, int i, int j ) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
        incSwaps();
        return a;
    }

    //Benoetigte Mehtode des Interfaces Runnable, noch ungenutzt
    public abstract void run();
}
