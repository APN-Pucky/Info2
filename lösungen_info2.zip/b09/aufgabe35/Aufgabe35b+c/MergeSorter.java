//
//  MergeSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//



public class MergeSorter extends Sorter {

    public MergeSorter(int[] a) {
        this.array = a;
    }

    public void sort() {
        mergesort(this.getArray(),0,this.getArray().length-1);

    }

    public void run() {
        sort();
    }

    public void mergesort(int[] a,int lo, int hi) {
        if (lo<hi)
        {
            // initialisiere die Mitte
            int m=(lo+hi)/2;
            // rufe mergesort fuer die untere Haelfte auf
            mergesort(a,lo, m);
            // rufe mergesort fuer die obere Haelfte auf
            mergesort(a,m+1, hi);
            // fuege die beiden Teilarrays wieder zusammen
            merge(a,lo, hi);
        }
    }


    public void merge(int[] a,int lo, int hi) {
    int i, j, k, m, n=hi-lo+1;
    int[] b = new int[a.length];
    k=0;
    // initialisiere die Mitte
    m=(lo+hi)/2;
    // untere Haelfte in Array b kopieren
    for (i=lo; i<=m; i++) {
        b[k++]=a[i];
        incSwaps();
    }
    // obere Haelfte in umgekehrter Reihenfolge in Array b kopieren
    for (j=hi; j>=m+1; j--) {
        b[k++]=a[j];
        incSwaps();
    }
    i=0; j=n-1; k=lo;
    // jeweils das naechstgroesste Element zurueckkopieren,
    // bis i und j sich ueberkreuzen
    while (i<=j) {
        incCompares();
        if (b[i]<=b[j]) {
            a[k++]=b[i++]; //a[k] auf b[i]; k und i anschliessend incrementieren
            incSwaps();		// Vertauschungen hochzaehlen
        }
        else{
            a[k++]=b[j--];
            incSwaps();		// Vertauschungen hochzaehlen
        }
    }

}

    
}
