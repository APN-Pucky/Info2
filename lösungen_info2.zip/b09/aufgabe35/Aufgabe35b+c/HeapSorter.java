//
//  HeapSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//



public class HeapSorter extends Sorter {

    public HeapSorter(int[] a) {
        this.array = a;
    }

    public void sort() {
        heapsort(this.getArray());
    }

    public void run() {
        sort();
    }

    /* Methode heap, erzeugt einen absteigenden Heap aus den der Methode �bergebenden Integer
    @param int[] a das Array mit den Zahlen
    */
    private void heap(int[] a) {
        //fuer alle Knoten, die Nachfolger haben
        for (int v=a.length/2-1; v>=0; v--)
            //repariere den Heap/die Heapeigenschaft
            restore (a,v,a.length);
    }

    /* Methode visualHeapsort,
    sortiert ein ihr uebergebenes Array von Integern,
    indem es zunaechst ein Heap erzeugt und anschliessend
    dessen Struktur zum schnellen Einsortieren nutzt
    @param int[] a das zu sortierende Array
    */
    public void heapsort(int[] a) {
        //erzeuge Heap
        heap(a);
        int n = a.length;
        //fuer alle n groesser 1
        while (n>=1)
        {
            n--;
            //vertausche das erste und letzte Element, dadurch ist das groesste hinten im Array
            swap(a, 0, n);
            // repariere den Heap
            restore(a,0,n);
        }
    }



    /*Methode restore,
    erzeugt einen Heap unterhalb des Knoten v
    @param int[] a das Array in dem der Heap gespeichert ist
    @param int v der Knoten unterhalb dessen der Heap "repariert" wird
    @param int n die Grenze, innerhalb derer der Heap "repariert" wird
    */
    private void restore(int[] a,int k, int n) {
        int w=2*k+1;    			// erster Nachfolgeknoten von k
        boolean heap = false;			// Abbruchvariable, falls der Teilbaum schon ein Heap ist
        while ((!heap) && (w<n))		// Solange kein Heap und der selektierte Knoten kleiner ist als der maximal zulaessige Knoten
        {
            incCompares();
            if (w+1<n) 				// gibt es einen zweiten Nachfolgeknoten?
            {
                incCompares();			// Vergleiche hochzaehlen
                if (a[w+1]>a[w])
                {
                    w++;		// hiernach ist w der groessere Nachfolge von k
                }
            }
            incCompares();			// Vergleiche hochzaehlen
            if (a[k]>=a[w]) heap = true;  			// k ist bereits Wurzel eines Heaps, verlasse Schleife
            else						// andernfalls
            {
                swap(a,k, w);	  				// tausche k und w
                k=w;		        			// den Heap weiter abwaerts
                w=2*k+1;
            }
        }
    }
    
}	// end class Heapsorter
