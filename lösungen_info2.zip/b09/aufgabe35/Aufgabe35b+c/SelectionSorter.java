//
//  SelectionSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//



public class SelectionSorter extends Sorter {

    public SelectionSorter(int[] a) {
        array = a;
    }

    public void selectionSort(int[] a) {
        int laenge = a.length;
        // eine FOR-Schleife um n mal das kleinste Element zu suchen
        for (int i = 0; i < laenge;i++) {
            int zwsp = i; // zun�chst wird das erste Element markiert
            for (int j = i; j < laenge; j++) {
                // wenn ein kleineres Element gefunden, so wird diese markiert.
                this.incCompares();
                if (a[j] < a[zwsp]) {
                    zwsp = j;
                }
            }
            // dann der Dreieckstausch hier mit der Funktion swap
            swap(a,i,zwsp);
        }
    }

    public void sort() {
        selectionSort(this.getArray());
    }
    
    public void run() {
        sort();
    }
}
