//
//  BubbleSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//


public class BubbleSorter extends Sorter {


    //Konstruktor, das Array wird uebergeben und intern gespeichert
    public BubbleSorter(int[] a) {
        array = a;
    }

    /* Geerbte Methode aus Sorter.class
    *@see Sorter.java
    */
    public void sort() {
        bubblesort(getArray());
    }

    //Die eigentliche Sortiermethode
    private void bubblesort(int[] a) {
        int hilf = 0;
        boolean vertauscht = false;
        int run = 0;
        do
        {
            run += 1;
            vertauscht = false;
            for (int i=0; i<a.length-run; i++)
            {
                this.incCompares(); // Vergleiche hochzaehlen
                if (a[i] > a[i+1])
                {
                    a = swap(a,i,i+1); // vertauschungen werden in Swap gezaehlt
                    vertauscht = true;
                }
            }
        }
        while (vertauscht);
    }
    
    // Geerbte Methode, ruft sort() auf
    public void run() {
        sort();
    }
            

}
  

