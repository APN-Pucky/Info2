//
//  QuickSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//



public class QuickSorter extends Sorter {

    public QuickSorter(int[] a) {
        this.array = a;
    }

    public void sort() {
        quicksort(this.getArray(),0,this.getArray().length-1);
    }

    public void run() {
        sort();
    }

    public void quicksort(int[] a,int lo, int hi) {

        int i=lo, j=hi;
        // initialisiere Mitte, auch eine Medianfunktion waere hier moeglich
        int x=a[(lo+hi)/2];
        //  Aufteilung
        // Solange i und j nicht aneinander vorbeilaufen
        while (i<=j)
        {
            while (a[i]<x) {
                i++; // incrementiere i solange im linken Teil kein kleineres Element als x gefunden wird
                this.incCompares();
            }
            while (a[j]>x) {
                j--; // decrementiere j solange im rechten teil kein groesseres Element als x gefunden wird
                this.incCompares();
            }
            this.incCompares();
            if (i<=j)
            {
                swap(a,i, j);	// dann tausche die beiden
                i++; j--;	//
            }
        }
        // Rekursion
        if (lo<j) quicksort(a,lo, j); //rufe Quicksort f�r die untere Haelfte des aktuellen arrays auf
        if (i<hi) quicksort(a,i, hi); //rufe Quicksort f�r die obere Haelfte des aktuellen arrays auf
    }
    
        

}
