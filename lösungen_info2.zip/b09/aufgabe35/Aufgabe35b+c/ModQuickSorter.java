//
//  ModQuickSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//


public class ModQuickSorter extends Sorter {

    protected int subSize;
    
    public ModQuickSorter(int[] a, int subSize) {
        this.array = a;
        this.subSize = subSize;
    }

    public void sort() {
        modQuicksort(this.getArray(),0,this.getArray().length-1, this.subSize);
    }

    public void run() {
        sort();
    }

    public void modQuicksort(int[] a, int lo, int hi, int subSize) {
        int i=lo, j=hi;
        int x=a[(lo+hi)/2];
        //  Aufteilung
        while (i<=j)
        {
            incCompares();
            while (a[i]<x) {	//suche kleineres element als x
                i++;                
            }
            incCompares();
            while (a[j]>x) {	//suche groesseres element als x
                j--;
            }
            incCompares();
            if (i<=j)
            {
                swap(a,i, j);	// Tausche
                i++; j--;
            }
        }
        // Rekursion
        // wenn Grenzen des Teilarrays kleiner oder gleich der Groesse sind rufe Insertionsort auf
        if (lo< j) {
            if ((j-lo)<=subSize) {
                modInsert(a,lo,j);
            }
            else {
                modQuicksort(a,lo, j,subSize);
            }
        }
        if (i<hi) {
            if ((hi-i)<=subSize) {
                modInsert(a,i,hi);
            }
            else {
                modQuicksort(a,i, hi,subSize);
            }
        }
    }

    /*
     * Wie Insertionsort, nur das hier auf dem Teilarray mit dem Grenzen li und re operiert wird
     */

    public void modInsert(int[] a,int li, int re) {
        int i, j, t;
        // die Beschraenkung findet hier statt
        // i laeuft nur von li bis re
        for (i=li; i<=re; i++)
        {
            j=i;
            t=a[j];
            while (j>0 && a[j-1]>t)
            {
                incCompares();
                incSwaps();
                a[j]=a[j-1];
                j--;
            }
            incSwaps();
            a[j]=t;
        }
    }
}
