//
//  Main.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Main extends JFrame implements ActionListener,ItemListener {

    // Swing Komponenten
    private JPanel jContentPane;
    private JButton jButton1 = new JButton("Proceed");
    private JLabel jLabel;
    private JLabel jLabel1;
    private JComboBox jComboBox;
    private JComboBox jComboBox1;
    private JTextArea log;
    private JScrollPane jScrollPane;

    // private Variablen
    private short data;			// welche datenquelle soll gewaehlt werden
    private short algo;			// welcher Algorithmus soll angewendet werden	
    private Sorter sort;		// Sortierer, welcher genau gewaehlt wird, kann zur laufzeit entschieden werden
    private int[] rate = new int[7];	// array das die "Performance"-kennziffern der Algorithmen aufnimmt

    public static void main(String[] args) {
        Main m = new Main();
        m.show();
    }
    
    /**
        * @throws java.awt.HeadlessException
        */
    public Main() {

        //ganz viele Initialisierengen
        jContentPane = new javax.swing.JPanel();
        java.awt.GridLayout layGridLayout = new java.awt.GridLayout();
        layGridLayout.setRows(3);
        layGridLayout.setColumns(2);
        jContentPane.setLayout(layGridLayout);
        jContentPane.add(getJLabel1(), null);
        jContentPane.add(getJLabel(), null);
        jComboBox = getJComboBox();
        jComboBox.addItemListener(this);
        jContentPane.add(jComboBox, null);
        jComboBox1 = getJComboBox1();
        jComboBox1.addItemListener(this);
        jContentPane.add(jComboBox1, null);
        jButton1 = getJButton1();
        jButton1.addActionListener(this);
        log = new JTextArea(1,10);
        jScrollPane = new JScrollPane(log);
        jContentPane.add(jScrollPane);
        jContentPane.add(jButton1, null);
        this.setContentPane(jContentPane);
        this.setSize(700, 200);
        this.setLocation(100, 100);
        this.addWindowListener(new java.awt.event.WindowAdapter() { 
            public void windowClosing(java.awt.event.WindowEvent e) {    
                System.exit(0);
            }
        });
    }

    /**
        * This method initializes this
        * 
        * @return void
        */
    private void initialize() {
        jContentPane = new javax.swing.JPanel();
        java.awt.GridLayout layGridLayout = new java.awt.GridLayout();
        layGridLayout.setRows(2);
        layGridLayout.setColumns(3);
        jContentPane.setLayout(layGridLayout);
        jContentPane.add(getJLabel1(), null);
        jContentPane.add(getJLabel(), null);
        jContentPane.add(getJComboBox(), null);
        jContentPane.add(getJComboBox1(), null);
        jButton1 = getJButton1();
        jButton1.addActionListener(this);
        jContentPane.add(jButton1, null);		
        this.setContentPane(jContentPane);

        this.setSize(500, 100);
        this.setLocation(100, 100);
        this.addWindowListener(new java.awt.event.WindowAdapter() { 
            public void windowClosing(java.awt.event.WindowEvent e) {    
                System.exit(0);
            }
        });
    }

    /**
        * This method initializes jLabel
        * 
        * @return javax.swing.JLabel
        */
    private javax.swing.JLabel getJLabel() {
        if(jLabel == null) {
            jLabel = new javax.swing.JLabel();
            jLabel.setText("W�hle Sortierverfahren");
        }
        return jLabel;
    }
    /**
        * This method initializes jLabel1
        * 
        * @return javax.swing.JLabel
        */
    private javax.swing.JLabel getJLabel1() {
        if(jLabel1 == null) {
            jLabel1 = new javax.swing.JLabel();
            jLabel1.setText("W�hle Generator");
        }
        return jLabel1;
    }
    /**
        * This method initializes jComboBox
        * 
        * @return javax.swing.JComboBox
        */
    private javax.swing.JComboBox getJComboBox() {
        if(jComboBox == null) {
            jComboBox = new javax.swing.JComboBox();
        }
        jComboBox.addItem("Build-in: 10 Elemente");		// Die zu waehlenden Konfigurationen
        jComboBox.addItem("Build-in: 100 Elemente");
        jComboBox.addItem("Build-in: 1000 Elemente");
        jComboBox.addItem("Build-in: 10000 Elemente");
        jComboBox.addItem("Datei-Aufsteigend");
        jComboBox.addItem("Datei-Absteigend");
        jComboBox.addItem("Datei-Zufall");
        return jComboBox;
    }
    /**
        * This method initializes jComboBox1
        * 
        * @return javax.swing.JComboBox
        */
    private javax.swing.JComboBox getJComboBox1() {
        if(jComboBox1 == null) {
            jComboBox1 = new javax.swing.JComboBox();
        }
        jComboBox1.addItem("Bubblesort");		// die zu waehlenden Algorithmen
        jComboBox1.addItem("Insertionsort");
        jComboBox1.addItem("Selectionsort");
        jComboBox1.addItem("Mergesort");
        jComboBox1.addItem("Quicksort");
        jComboBox1.addItem("Modifiziertes Quicksort");
        jComboBox1.addItem("Heapsort");
        jComboBox1.addItem("Alle Algorithmen nacheinander");
        return jComboBox1;
    }
    
    /**
        * This method initializes jButton1
        * 
        * @return javax.swing.JButton
        */
    private javax.swing.JButton getJButton1() {
        if(jButton1 == null) {
            jButton1 = new javax.swing.JButton();
            jButton1.setText("GO"); 
        }
        return jButton1;
    }
    
    /**
        methode die, die Aktion starten
     */

    public void actionPerformed(java.awt.event.ActionEvent e) {
        //log.append("Uuuuuuuuuuuuuuuund Action!\n");
        log.append("Datenquelle: "+jComboBox.getSelectedItem()+"\n"); // angabe der gewaehlten datenquelle
        log.append("Algorithmus: "+jComboBox1.getSelectedItem()+"\n");// angabe des gewaehlten algorithmus
        if (algo == 0) doBubble();		
        if (algo == 1) doInsert();
        if (algo == 2) doSelect();
        if (algo == 3) doMerge();
        if (algo == 4) doQuick();
        if (algo == 5) doModQuick();
        if (algo == 6) doHeap();
        if (algo == 7) {    // Wenn alle durchgefuehrt werden sollen
            algo=0;		// das anpassen von algo sorgt dafuer, dass die Kennziffern passend gespeichert werden
            doBubble();
            algo++;
            doInsert();
            algo++;
            doSelect();
            algo++;
            doMerge();
            algo++;
            doQuick();
            algo++;
            doModQuick();
            algo++;
            doHeap();
            log.append("Der Effizienteste Algorithmus ist: "+getBest()+"\n");
            return;
        }
    }

    // Notwendige Methode des Interfaces ItemListener,
    // achtet auf Veraenderungen in den Comboboxen
    public void itemStateChanged(java.awt.event.ItemEvent e) {
        Object source = e.getSource();
        if (source == jComboBox) {
            data =(short) jComboBox.getSelectedIndex();//"\n");
        }
        if (source == jComboBox1) {
            algo = (short) jComboBox1.getSelectedIndex();//+"\n");
        }
    }

    //Sucht den effizientesten Algorithmus heraus, gemessen an der Kennziffer
    private String getBest() {
        int min = 0;
        // Such das Minimum
        for (int i = 0; i< rate.length; i++) {
            if (rate[i] < rate[min])
                min = i;
        }
        String back = "Fehler!";
        if (min == 0) back = "Bubblesort";
        if (min == 1) back = "Insertionsort";
        if (min == 2) back = "Selectionsort";
        if (min == 3) back = "Mergesort";
        if (min == 4) back = "Quicksort";
        if (min == 5) back = "Modifiziertes Quicksort";
        if (min == 6) back = "Heapsort";
        return back;
    }
    



    
    /* Jetzt kommen die Aufrufe fuer die Algorithmen,
        es wird jeweils ein Array gefuellt,
        ein Sortierer angelegt,
        sortiert,
        und die Kennziffern gespeichert
        und ausgegeben
        */

    
    private void doBubble() {
        int[] a = fillArray();
        sort = new BubbleSorter(a);
        log.append("\n Running Bubblesort\n");
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r Bubblesort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }

    
        
    private void doInsert() {
        int[] a = fillArray();
        sort = new InsertionSorter(a);
        log.append("\n Running Insertionsort\n");
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r Insertionsort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }

    private void doSelect() {
        int[] a = fillArray();
        sort = new SelectionSorter(a);
        log.append("\n Running Selectionsort\n");
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r Selectionsort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }

    private void doMerge() {
        int[] a = fillArray();
        sort = new MergeSorter(a);
        log.append("\n Running Mergesort\n");	
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r Mergesort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }

    private void doQuick() {
        int[] a = fillArray();
        sort = new QuickSorter(a);
        log.append("\n Running Quicksort\n");
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r Quicksort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }

    private void doModQuick() {
        int[] a = fillArray();
        sort = new ModQuickSorter(a,13);
        log.append("\n Running modifiziertes Quicksort\n");
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r modifiziertes Quicksort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }
        
    private void doHeap() {
        int[] a = fillArray();
        sort = new HeapSorter(a);
        log.append("\n Running Heapsort\n");
        sort.run();
        log.append("Anzahl Vertauschungen: "+sort.getSwaps()+"\n");
        log.append("Anzahl Vergleiche: "+sort.getCompares()+"\n");
        log.append("Algo: "+algo+" Rate.length: "+rate.length+"\n");
        rate[algo] = score(sort.getSwaps(),sort.getCompares());
        log.append("Rating f�r Heapsort bei "+jComboBox.getSelectedIndex()+" ist "+rate[algo]+"\n");
    }


    // Methode um die Algorithmen - nach der Aufgabenstellung zu scoren
    private int score(int vertauschungen, int vergleiche) {
        return 2*vertauschungen+vergleiche;
    }


    // Fuellt das ein Array
    private int[] fillArray() {
        int[] back = new int[100]; // hat nicht viel zu bedeuten, falls data nicht initialisiert ist, wird das Array wenigstens initialisiert
        if (data == 0) back = new ZufallBuildIn(0).getArray(10); // wichtig hierbei, dass ZufallBuildin immer mit dem gleichen Seed gestartet wird um vergleichbare ergebnisse zu erhalten
        if (data == 1) back = new ZufallBuildIn(0).getArray(100);
        if (data == 2) back = new ZufallBuildIn(0).getArray(1000);
        if (data == 3) back = new ZufallBuildIn(0).getArray(10000);
        if (data == 4) back = loadFromFile("aufsteigend.txt");
        if (data == 5) back = loadFromFile("absteigend.txt");
        if (data == 6) back = loadFromFile("zufall.txt");        
        return back;
    }

    /* eine Methode um ein File mit Zahlen in ein IntegerArray zu laden,
        * leider mu�te ich vorher festlegen, wie gro� das Array sein mu�,
        * andere Methoden waeren zu aufwendig gewesen*/
    private static int[] loadFromFile(String filename) {
        int anzahl = 100; // die Anzahl wird festgelegt
        int[] back;		  // das Array definiert
        try {
            // ein File-Stream wird geoeffnet
            FileReader file = new FileReader(filename);
            // ein gepufferter Stream wird geoeffnet
            BufferedReader buffy = new BufferedReader(file);
            // eine bool'sche Variable EndOfFile definiert
            boolean eof = false;
            // das ist glaube ich nicht noetig
            int i = 0;
            // das Array wird initialisiert
            back = new int[anzahl];
            // eine Schleife liest nun aus dem File
            while (!eof || i< anzahl ) {
                // in einen String
                String in = buffy.readLine();
                try {
                    if (in != null) {
                        // die einzelnen Strings werden geparst
                        back[i] = Integer.parseInt(in);
                    }
                }
                // der Rest ist "Aufraeumarbeit"
                catch (NumberFormatException e) {
                    buffy.close();
                    JOptionPane.showMessageDialog(null,"NAN");
                }
                i++;
                if (in == null){
                    eof = true;
                }
            }
            buffy.close();
        }
        catch (IOException e) {
            JOptionPane.showMessageDialog(null,"File could not be loaded!");
            back = new int[100];
        }
        return back; // das Array wird zurueckgegeben
    }
    
    
}	
