//
//  InsertionSorter.java
//  
//
//  Created by Julian Hartmann on Tue Jun 22 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//



public class InsertionSorter extends Sorter {

    public InsertionSorter(int[] a) {
        this.array = a;
    }

    public void sort() {
        insertionSort(this.getArray());
    }

    public void run() {
        sort();
    }

    public void insertionSort(int[] a){
        int i, j, t;
        // f�r n Durchlaeufe
        for (i=1; i<a.length; i++)
        {
            j=i;
            t=a[j]; // Zwischenspeichern des "einzusortierenden" Elementes
                    //Finde die Position f�r das ite Element im sortierten Teilarray
            while (j>0 && a[j-1]>t)
            {
                incCompares();
                swap(a,j,j-1);
                //a[j]=a[j-1];
                j--;
            }
            //setze das Element ein
            a[j]=t;
        }
    }

}
