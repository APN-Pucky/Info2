// file "Aufgabe23.java"

import java.awt.*;
import java.io.*;
import java.util.Calendar;

import javax.swing.*;

/**
 * Rahmen zur Aufgabe 23.
 * Verwendet ein (privates) Visualizer-Objekt, um die
 * Animation der Sortieralgorithmen darzustellen.
 * 
 * @author    Daniel Ehlke, Julian Hartmann
 * @version   1.0 SE (student edition)
 * 
 * @see       Visualizer
 */
public class Aufgabe35 implements Runnable  {
    
    // statisches Attribut fuer Visualizer-Objekt (fuer die Animation noetig)
    private static Visualizer v = null;
    // Datenformat; also Zufallszahlengenerator oder eine der Dateien
    private static short data = 0;
    // Eines der Algorithmen
    private static short algo = 0;
    // selbsterklaerend
    private static int animationSpeed = 100;

    //Konstruktor
    public Aufgabe35(short dat, short alg) {
        data = dat;
        algo = alg;
        run();
    }

    
    /* Array mit den benoetigten (Zufalls-) Zahlen fuellen
     * Hierzu mehrere M�glichkeiten
     * Die in Aufgabe10 erstellten Generatoren
     * und die 3 Dateien mit Zahlen k�nnen geladen werden.
        */
    private static int[] fillArray(int[] back) {
        back = new int[100];
        if (data == 0) {
            back = new ZufallBuildIn().getArray(100);
        }
        if (data == 1){
            back = new ZufallParam(7).getArray(100);
        }
        if (data == 2) {
            back = new ZufallParam(23).getArray(100);
        }
        if (data == 3){
            back = loadFromFile("aufsteigend.txt");
        }
        if (data == 4) {
            back = loadFromFile("absteigend.txt");
        }
        if (data == 5) {
            back = loadFromFile("zufall.txt");
        }
        if(data<0 || data>5) {
            back = loadFromFile("zufall.txt");
        }
        return back;
    }
    
    // zaehlt einen Countdown herunter und zeigt diesen auch an
    private static void countdown(int seconds) {
        if (v == null)
            throw new IllegalStateException("Visualizer-Objekt v "
                                            +"existiert nicht!");
        for (int i=seconds; i>0; i--) {
            v.setLegend("Start in "+i+" Sekunden ...");
            v.repaint();
            v.sleepRealtime(1000);
        }
    }
    
    /**
     * Das Hauptprogramm fuer die Aufgabe 23.
     *
     * @param args  datenquelle, sortieralgorithmus
     */
    public static void main(String[] args) {
    	try {
    		data = Short.parseShort(args[0]);
    		algo = Short.parseShort(args[1]);
    	}
    	catch (Exception n){
    		System.out.println("Usage: java Aufgabe23Kopie datenquelle sortierverfahren");
			System.out.println("mit 0 = Build-in Zufall");
			System.out.println("mit 1 = Generator7");
			System.out.println("mit 2 = Generator23");
			System.out.println("mit 3 = Datei Aufsteigend");
			System.out.println("mit 4 = Datei Absteigend");
			System.out.println("mit 5 = Datei Zufall");
			System.out.println("mit 0 = Bubblesort");
			System.out.println("mit 1 = Selectionsort");
			System.out.println("mit 2 = Insertionsort");
			System.out.println("mit 3 = Mergesort");
			System.out.println("mit 4 = Quicksort");
			System.out.println("mit 5 = ModQuicksort");
                        System.out.println("mit 6 = Heapsort");
    		
    	}
    	System.out.println("DatenQuelle ist: "+ data);
    	System.out.println("Algorithmus ist: " + algo);
        // Nachdem die Parameter geparsed wurden wird eine Instanz von Aufgabe23 erzeugt.
        Aufgabe35 aufg= new Aufgabe35(data, algo);  
    }

    /*
     *Methode des Interfaces Runnable,
     *ruft hier in Abhaengigkeit des gewaehlten Parameters einen der Sortieralgorithmen auf
     */
    public void run() {
        if (algo == 0) runBubble();
        if (algo == 1) runSelection();
        if (algo == 2) runInsertion();
        if (algo == 3) runMerge();
        if (algo == 4) runQuick();
        if (algo == 5) runModQuick();
        if (algo == 6) runHeapsort();
    }
    
    /**
     * Sortiert ein int-Array mit dem Bubble-Sort Algorithmus
     * (Code siehe Aufgabe 24) und visualisiert dies mit Hilfe
     * eines (statischen) Visualizer-Objekts v, welches existieren muss.
     * 
     * @param a   das zu sortierende Array
     * 
     * @throws IllegalStateException falls das Visualizer-Objekt nicht existiert
     */
    public static void visualBubbleSort(int[] a) {
        if (v == null)
            throw new IllegalStateException("Visualizer-Objekt v "
                                            +"existiert nicht!");
        v.setLegend("Bubble Sort");
        int hilf = 0;
        boolean vertauscht = false;
        int run = 0;
        do {
            run += 1;
            vertauscht = false;
            for (int i=0; i<a.length-run; i++) {
                v.setLabel(i, "i");
                v.setHighlight(i, v.VERTICAL_HIGHLIGHT);
                if (a[i] > a[i+1]) {
                    hilf = a[i];
                    a[i] = a[i+1];
                    a[i+1] = hilf;
                    vertauscht = true;
                }
                v.setColor(i, Color.RED);
                v.setColor(i+1,Color.ORANGE);
                v.setData(a);
                v.repaint(); // alles neuzeichnen
                v.sleep(animationSpeed); // und warten
                v.setLabel(i, "");
                v.setHighlight(i, v.NO_HIGHLIGHT);
                if (i == a.length-run-1)
                    v.setColor(i+1, Color.BLACK);
            }
        } while (vertauscht);
        v.setData(a);
        v.setLegend("Bubble Sort (terminiert)");
        v.repaint();
    }
    
    public static void runBubble() {
	
		int[] a = new int[100];
		a = fillArray(a);
		v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
							   // die Animation wird damit moeglich

		countdown(2);          // es spannend machen ;-)
		visualBubbleSort(a);   // visuell sortieren
		v.sleepRealtime(animationSpeed); // 5 Sekunden warten
    	
    }
    
    public static void selectionSort(int[] a) {
		if (v == null)
					throw new IllegalStateException("Visualizer-Objekt v "
													+"existiert nicht!");
		v.setLegend("Selection Sort");
		int laenge = a.length;
		// eine FOR-Schleife um n mal das kleinste Element zu suchen
		for (int i = 0; i < laenge;i++) {
                    int zwsp = i; // zun�chst wird das erste Element markiert
                    v.setLabel(zwsp,"min");
                    v.setHighlight(zwsp,v.HORIZONTAL_HIGHLIGHT);
                    v.sleepRealtime(animationSpeed);
                    for (int j = i; j < laenge; j++) {
			v.setLabel(j,"j");
			v.setHighlight(j, v.VERTICAL_HIGHLIGHT);
                        // wenn ein kleineres Element gefunden, so wird diese markiert. 
                        if (a[j] < a[zwsp]) {
                            v.setLabel(zwsp,"");
                            v.setHighlight(zwsp,v.NO_HIGHLIGHT);
                            zwsp = j;
                            //v.setLabel(zwsp,"min");
                            //v.setHighlight(zwsp,v.HORIZONTAL_HIGHLIGHT);
                            v.repaint();
                            v.sleepRealtime(animationSpeed);
                        }
                        v.setLabel(zwsp,"min");
                        v.setHighlight(zwsp,v.HORIZONTAL_HIGHLIGHT);
                        v.repaint();
                        v.sleepRealtime(animationSpeed);
                        v.setHighlight(j, v.NO_HIGHLIGHT);
                        v.setLabel(j, "");
                        v.setLabel(zwsp,"");
                        v.setHighlight(zwsp,v.NO_HIGHLIGHT);
                    }
                    // dann der Dreieckstausch hier mit der Funktion swap
                    swap(a,i,zwsp);
                    v.setData(a);
                    v.repaint();
                    // kurz angehalten
                    v.sleepRealtime(animationSpeed);
                    // und die Anzeige wieder aktualisiert
                    // hier werden die �brigen Punkte wieder schwarz gefaerbt
                    for (int b=0;b<=i;b++)
                        v.setColor(b,Color.BLACK);
                    v.repaint();
                    v.setHighlight(i, v.NO_HIGHLIGHT);
                    v.setLabel(i, "");
                    
		}	
		v.setData(a);
		v.setLegend("Selection Sort (terminiert)");
                v.repaint();
    }
    
	public static void runSelection() {
            int[] a = new int[100];
            a = fillArray(a);
            
            v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
                                   // die Animation wird damit moeglich

            countdown(2);          // es spannend machen ;-)
            selectionSort(a);   // visuell sortieren
        }

    
	
	public static void insertionSort(int[] a){
            int i, j, t;
            v.setLegend("Insertion Sort");
            // f�r n Durchlaeufe
            for (i=1; i<a.length; i++)
            {
                v.setLabel(i,"i");
                v.setHighlight(i,v.VERTICAL_HIGHLIGHT);
                j=i;
                t=a[j]; // Zwischenspeichern des "einzusortierenden" Elementes
                //Finde die Position f�r das ite Element im sortierten Teilarray 
                while (j>0 && a[j-1]>t)
                {
                    v.setColor(j,Color.GREEN);
                    v.setColor(j-1,Color.BLUE);
                    a[j]=a[j-1];
                    j--;
                    v.sleepRealtime(animationSpeed);
                    v.setData(a);
                    v.repaint();
                    for(int b=0;b <i; b++)
                        v.setColor(b, Color.RED);
                    v.setLabel(j,"");
                }
                //setze das Element ein
                a[j]=t;
                v.repaint();
                v.setLabel(i,"");
                v.setHighlight(i,v.NO_HIGHLIGHT);
            }
            v.setData(a);
            v.setLegend("Insertion Sort (terminiert)");
            v.repaint();
        }

        public static void runInsertion() {
            int[] a = new int[100];
            a = fillArray(a);
            
            v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
                                   // die Animation wird damit moeglich

            countdown(2);      	    // es spannend machen ;-)
            insertionSort(a);   // visuell sortieren
            v.sleepRealtime(5000); // 5 Sekunden warten
	}
	
	
	public static void mergesort(int[] a,int lo, int hi)
            {
            v.setLegend("Merge Sort");

            if (lo<hi)
            {
                // initialisiere die Mitte
                int m=(lo+hi)/2;
                // rufe mergesort fuer die untere Haelfte auf
                mergesort(a,lo, m);
                v.sleepRealtime(animationSpeed);
                // rufe mergesort fuer die obere Haelfte auf
                mergesort(a,m+1, hi);
                v.sleepRealtime(animationSpeed);
                // fuege die beiden Teilarrays wieder zusammen
                merge(a,lo, hi);
            }
            }


    public static void merge(int[] a,int lo, int hi)
    {
        int i, j, k, m, n=hi-lo+1;
        int[] b = new int[a.length];
        k=0;
        // initialisiere die Mitte
        m=(lo+hi)/2;
        v.setLabel(m,"Mitte");

        // untere Haelfte in Array b kopieren
        for (i=lo; i<=m; i++) {
            b[k++]=a[i];
            v.setData(a);
            v.repaint();
        }

        // obere Haelfte in umgekehrter Reihenfolge in Array b kopieren
        for (j=hi; j>=m+1; j--) {
            b[k++]=a[j];
            v.setData(a);
            v.repaint();
        }
        


        i=0; j=n-1; k=lo;

        // jeweils das naechstgroesste Element zurueckkopieren,
        // bis i und j sich ueberkreuzen
        while (i<=j) {

            if (b[i]<=b[j]) {
                //v.setLabel(i,"i");
                v.setHighlight(j,v.VERTICAL_HIGHLIGHT);
                a[k++]=b[i++]; //a[k] auf b[i]; k und i anschliessend incrementieren
                v.setData(b);
                v.sleepRealtime(animationSpeed);
                v.repaint();
                v.setLabel(i,"");
                v.setHighlight(j,v.NO_HIGHLIGHT);

            }
            else{
                a[k++]=b[j--];
                v.setData(b);
                v.sleepRealtime(animationSpeed);
                v.repaint();
            }
            v.setData(b);
            v.repaint();
            v.setHighlight(j,v.NO_HIGHLIGHT);
            v.repaint();

        }
        v.setData(a);
        v.setLegend("Merge Sort");
        v.repaint();
        v.setLabel(m,"");

    }	

	
	public static void runMerge() {
            int[] a = new int[100];
            a = fillArray(a);
            
            v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
                                   // die Animation wird damit moeglich

            countdown(1);          // es spannend machen ;-)
            mergesort(a,0,99);   // visuell sortieren
        }
    
    
    public static void quickSort(int[] a,int lo, int hi) {

        int i=lo, j=hi;
        // initialisiere Mitte, auch eine Medianfunktion waere hier moeglich
        int x=a[(lo+hi)/2];
        v.setHighlight(x,v.VERTICAL_HIGHLIGHT);
        v.setLabel(x,"Mitte");
        v.setLegend("QuickSort");
        v.repaint();

        //  Aufteilung
        // Solange i und j nicht aneinander vorbeilaufen
        while (i<=j)
        {
            while (a[i]<x) i++; // incrementiere i solange im linken Teil kein kleineres Element als x gefunden wird
            while (a[j]>x) j--; // decrementiere j solange im rechten teil kein groesseres Element als x gefunden wird
            if (i<=j)
            {
                swap(a,i, j);	// dann tausche die beiden
                i++; j--;	// 
            }
        }
        v.setHighlight(x,v.NO_HIGHLIGHT);
        v.setLabel(x,"");
        // Rekursion
        if (lo<j) quickSort(a,lo, j); //rufe Quicksort f�r die untere Haelfte des aktuellen arrays auf 
        v.setData(a);
        v.repaint();
        if (i<hi) quickSort(a,i, hi); //rufe Quicksort f�r die obere Haelfte des aktuellen arrays auf
        v.setData(a);
        v.repaint();
    }
    /*
     * Wie Quicksort, nur das bei einer festgelegten Groesse des Teilarrays, dieses mit Insertionsort sortiert wird
     */
	
    public static void modQuicksort(int[] a, int lo, int hi, int subSize) {
	int i=lo, j=hi;
	int x=a[(lo+hi)/2];
	v.setHighlight(x,v.VERTICAL_HIGHLIGHT);
	v.setLabel(x,"Mitte");
	v.setLegend("Modifiziertes QuickSort");
	v.repaint();
	
	//  Aufteilung
	while (i<=j)
	{    
	    while (a[i]<x) i++; 
	    while (a[j]>x) j--;
	    if (i<=j)
	    {
		swap(a,i, j);
		i++; j--;
	    }
	}
	v.setHighlight(x,v.NO_HIGHLIGHT);
	v.setLabel(x,"");
	// Rekursion
	// wenn Grenzen des Teilarrays kleiner oder gleich der Groesse sind rufe Insertionsort auf
        if (lo< j) {
            if ((j-lo)<=subSize) {
                modInsert(a,lo,j);
            }
            else {
                modQuicksort(a,lo, j,subSize);
                v.setData(a);
                v.repaint();
            }
        }
        if (i<hi) {
            if ((hi-i)<=subSize) {
                modInsert(a,i,hi);
            }
            else {
                modQuicksort(a,i, hi,subSize);
                v.setData(a);
                v.repaint();
            }
        }
        
        
    }
    /*
     * Wie Insertionsort, nur das hier auf dem Teilarray mit dem Grenzen li und re operiert wird
     */
    public static void modInsert(int[] a,int li, int re) {
	int i, j, t;
        // die Beschraenkung findet hier statt
        // i laeuft nur von li bis re
        for (i=li; i<=re; i++)
        {
            v.setLabel(i,"i");
            v.setHighlight(i,v.VERTICAL_HIGHLIGHT);
            j=i;
            t=a[j];
            while (j>0 && a[j-1]>t)
            {
                v.setColor(j,Color.BLACK);
                v.setColor(j-1,Color.YELLOW);
                a[j]=a[j-1];
                j--;
                v.sleepRealtime(animationSpeed);
                v.setData(a);
                v.repaint();
                for(int b=0;b <i; b++)
                    v.setColor(b, Color.RED);
                v.setLabel(j,"");
            }
            a[j]=t;
            v.repaint();
            v.setLabel(i,"");
            v.setHighlight(i,v.NO_HIGHLIGHT);

        }
    }


    public static void runQuick() {
        int[] a = new int[100];
        a = fillArray(a);

        v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
                               // die Animation wird damit moeglich

        countdown(1);          // es spannend machen ;-)
        quickSort(a,0,99);   // visuell sortieren
        }

    public static void runModQuick() {
        for (int size = 10; size< 30; size++) {

            int[] a = new int[100];
            a = fillArray(a);

            v = new Visualizer(a); 		// Visualizer-Objekt erzeugen und v zuweisen
                                     // die Animation wird damit moeglich

            countdown(1);          		// es spannend machen ;-)
            long time = System.currentTimeMillis();
            modQuicksort(a,0,99,size);  // visuell sortieren
            time = System.currentTimeMillis() - time;
            v.setLegend("ModQuicksort: SubArraygr��e "+size+" Zeit: "+time );
            v.sleepRealtime(5000); 		// 5 Sekunden warten
	}
    }




    
    /* Methode heap, erzeugt einen absteigenden Heap aus den der Methode �bergebenden Integer
        @param int[] a das Array mit den Zahlen
        */
    private static void heap(int[] a)
    {
        //fuer alle Knoten, die Nachfolger haben
        for (int v=a.length/2-1; v>=0; v--)
            //repariere den Heap/die Heapeigenschaft
            restore (a,v,a.length);
    }

    /* Methode visualHeapsort,
        sortiert ein ihr uebergebenes Array von Integern,
        indem es zunaechst ein Heap erzeugt und anschliessend
        dessen Struktur zum schnellen Einsortieren nutzt
        @param int[] a das zu sortierende Array
        */
    public static void heapsort(int[] a)
    {
        //erzeuge Heap
        heap(a);
        int n = a.length;
        //fuer alle n groesser 1
        while (n>=1)
        {
            n--;
            //vertausche das erste und letzte Element, dadurch ist das groesste hinten im Array
            swap(a, 0, n);
            // repariere den Heap
            restore(a,0,n);
        }
    }



    /*Methode restore,
        erzeugt einen Heap unterhalb des Knoten v
        @param int[] a das Array in dem der Heap gespeichert ist
        @param int v der Knoten unterhalb dessen der Heap "repariert" wird
        @param int n die Grenze, innerhalb derer der Heap "repariert" wird
        */
    private static void restore(int[] a,int k, int n)
    {
        int w=2*k+1;    			// erster Nachfolgeknoten von k
        boolean heap = false;			// Abbruchvariable, falls der Teilbaum schon ein Heap ist
        while ((!heap) && (w<n))		// Solange kein Heap und der selektierte Knoten kleiner ist als der maximal zulaessige Knoten 
        {
            v.setLabel(k,"Akt.Wurzel");
            v.setColor(k,Color.BLACK);
            v.setHighlight(k,Visualizer.VERTICAL_HIGHLIGHT);
            v.setColor(w,Color.GREEN);
            v.setHighlight(k,Visualizer.CROSS_HIGHLIGHT);
            
            v.repaint();
            v.sleepRealtime(animationSpeed);
            
            if (w+1<n) 				// gibt es einen zweiten Nachfolgeknoten?
            {
                v.setColor(w+1,Color.BLACK);
                v.setHighlight(w+1,Visualizer.CROSS_HIGHLIGHT);
                v.repaint();
                v.sleepRealtime(animationSpeed);
                if (a[w+1]>a[w])
                {
                    v.setColor(w,Color.RED);
                    v.setHighlight(w,Visualizer.NO_HIGHLIGHT);                    
                    w++;		// hiernach ist w der groessere Nachfolge von k
                    v.setLabel(w,"GR��ER");
                    v.setColor(w,Color.BLUE);
                    v.setHighlight(w,Visualizer.CROSS_HIGHLIGHT);

                    v.repaint();
                    v.sleepRealtime(animationSpeed);
                    
                    v.setLabel(w-1,"");
                    v.setColor(w-1,Color.RED);
                    v.setHighlight(w-1,Visualizer.NO_HIGHLIGHT);
                    v.setLabel(w,"");
                    v.setColor(w,Color.RED);
                    v.setHighlight(w,Visualizer.NO_HIGHLIGHT);
                    v.setLabel(w+1,"");
                    v.setColor(w+1,Color.RED);
                    v.setHighlight(w+1,Visualizer.NO_HIGHLIGHT);
                    
                }
                else
                {
                    v.setLabel(w,"GR��ER");
                    v.setColor(w,Color.BLUE);
                    v.setHighlight(w,Visualizer.CROSS_HIGHLIGHT);
                    v.setColor(w+1,Color.RED);
                    v.setHighlight(w+1,Visualizer.NO_HIGHLIGHT);

                    v.repaint();
                    v.sleepRealtime(animationSpeed);

                    v.setLabel(w,"");
                    v.setColor(w,Color.RED);
                    v.setHighlight(w,Visualizer.NO_HIGHLIGHT);
                    v.setLabel(w+1,"");
                    v.setColor(w+1,Color.RED);
                    v.setHighlight(w+1,Visualizer.NO_HIGHLIGHT);
                    
                }
            }
            v.setLabel(w,"Akt.Wurzel");
            v.setColor(k,Color.BLACK);
            v.setHighlight(k,Visualizer.VERTICAL_HIGHLIGHT);
            v.repaint();
            v.sleepRealtime(animationSpeed);
            

            if (a[k]>=a[w]) heap = true;  			// k ist bereits Wurzel eines Heaps, verlasse Schleife
            else						// andernfalls
            {
                v.setLabel(k,"");
                v.setHighlight(k,Visualizer.NO_HIGHLIGHT);
                v.setColor(k,Color.RED);
                v.setLabel(w,"");
                v.setHighlight(w,Visualizer.NO_HIGHLIGHT);
                v.setColor(w,Color.RED);                
                v.repaint();
                v.sleepRealtime(animationSpeed);
                
                swap(a,k, w);	  				// tausche k und w
                k=w;		        			// den Heap weiter abwaerts
                w=2*k+1;
                v.setLabel(k,"Akt.Wurzel");
                v.setHighlight(k,Visualizer.VERTICAL_HIGHLIGHT);
                v.setColor(k,Color.BLACK);
                if (w<n)
                {
                    v.setHighlight(w,Visualizer.CROSS_HIGHLIGHT);
                    v.setColor(w,Color.BLACK);
                }
                v.repaint();
                v.sleepRealtime(animationSpeed);
            }
            v.setLabel(k,"");
            v.setHighlight(k,Visualizer.NO_HIGHLIGHT);
            v.setColor(k,Color.RED);
            if (w<n)
            {
                v.setLabel(w,"");
                v.setHighlight(w,Visualizer.NO_HIGHLIGHT);
                v.setColor(w,Color.RED);
            }
            if (w+1<n)
            {
                v.setLabel(w+1,"");
                v.setHighlight(w+1,Visualizer.NO_HIGHLIGHT);
                v.setColor(w+1,Color.RED);
            }
            
            v.repaint();
            v.sleepRealtime(animationSpeed);
            
        }
    }

    public static void runHeapsort() {
        int[] a = new int[100];
        a = fillArray(a);

        v = new Visualizer(a); // Visualizer-Objekt erzeugen und v zuweisen
                               // die Animation wird damit moeglich

        countdown(1);          // es spannend machen ;-)
        v.setLegend("Heapsort");
        heapsort(a);   // visuell sortieren
        v.setLegend("Heapsort beendet");
 }
    







    /*
     * Hilfsfunktion swap,
     * tauscht im Array a die Elemente an den Positionen i und j
     */
    public static void swap(int[]a,int i, int j)
    {
        int t=a[i]; // speichere Element i zwischen
        v.setData(a);
        v.setColor(i,Color.BLUE);
        v.setColor(j, Color.GREEN);
        v.sleepRealtime(animationSpeed);
        v.repaint();
        a[i]=a[j]; 	// kopiere Element j ueber i
        a[j]=t;		// ueberschreibe j mit dem Zwischengespeicherten Wert von i
        v.setColor(i,Color.RED);
        v.setColor(j, Color.RED);
    }




    // Methode, die den Index des groesseren Elementes zur�ckgibt
    private static int max(int[] a,int i,int j) {
        if (a[i]< a[j]) {
            return j;
        }
        else {
            return i;
        }
    }
                
    
    /* eine Methode um ein File mit Zahlen in ein IntegerArray zu laden,
     * leider mu�te ich vorher festlegen, wie gro� das Array sein mu�,
     * andere Methoden w�ren zu aufwendig gewesen*/
    private static int[] loadFromFile(String filename) {
	int anzahl = 100; // die Anzahl wird festgelegt
	int[] back;		  // das Array definiert
	try {
	    // ein File-Stream wird ge�ffnet
	    FileReader file = new FileReader(filename);
	    // ein gepufferter Stream wird ge�ffnet 
	    BufferedReader buffy = new BufferedReader(file);
	    // eine bool'sche Variable EndOfFile definiert
	    boolean eof = false; 							
	    // das ist glaube ich nicht n�tig
	    int i = 0;
	    // das Array wird initialisiert										
	    back = new int[anzahl];
	    // eine Schleife liest nun aus dem File							
	    while (!eof || i< anzahl ) {
		// in einen String					
		String in = buffy.readLine();				
		try {
                    if (in != null) {
                        // die einzelnen Strings werden geparst
                        back[i] = Integer.parseInt(in);
                    }
                }
			   // der Rest ist "Aufr�umarbeit"
                catch (NumberFormatException e) {
                    buffy.close();
                    JOptionPane.showMessageDialog(null,"NAN");
                }
                i++;
                if (in == null){
                    eof = true;
                }
            }
            buffy.close();
        }
        catch (IOException e) {
            JOptionPane.showMessageDialog(null,"File could not be loaded!");
            back = new int[100];
        }
        return back; // das Array wird zur�ckgegeben
   }
    
} // class Aufgabe23