/*
 * Created on 06.05.2004
 */


/**
 * @author julianhartmann
 * @version 0.2
 * 
 */
public class ZufallParam extends Zufallszahlengenerator {

    /*
     * private Variablen
     */
    protected int a; // Multiplikator
    protected int c; // Inkrement
    protected int m; // Modulus
    protected int r; // Startwert
    
    /*
     * Leerer Konstruktor,
     * mit Werten, wie in der Aufgabenstellung(ausser Inkrement)
     */    
    public ZufallParam(){
        a = 21;
        c = 1;
        m = 100;
        r = 1;
    }
    
    /*
     * Konstruktor
     * ein Zugest�ndnis an die Aufgabenstellung
     * @param incr Inkrement
     */
    
    public ZufallParam(int incr) {
        a = 21;
        c = incr;
        m = 100;
        r = 1;        
    }
    
   /*
    * Konstruktor, mit der M�glichkeit, alle
    * parameter einzeln zu setzen
    * @param mult Multiplikator
    * @param inc Inkrement
    * @param mod Modulo
    * @param start Startwert
    */
    
    public ZufallParam(int mult, int inc, int mod, int start) {
        a = mult;
        c = inc;
        m = mod;
        r = start;
    }
    /*
     * Methode, um eine Zufallszahlen wieder zugeben, 
     * der generierte Wert wird dabei zum Startwert, des 
     * n�chsten Wertes
     */
    
    public int nextInt() {
        r = ((a*r+c) % m);
        return (r);
    }
	
	public int[] getArray(int anzahl){
		int[] back = new int[anzahl];
		for (int i=0; i< anzahl; i++){
			back[i] = this.nextInt();
		}
		return back;
	}
}
