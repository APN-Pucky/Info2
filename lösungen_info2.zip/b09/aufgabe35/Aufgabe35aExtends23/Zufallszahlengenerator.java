/*
 * Created on 04.05.2004
 *
 * 
 */


/*
 * Zufallszahlengenerator.java 
 */


/**
 *
 * @author  Julian Hartmann
 * @version 0.5a
 */
abstract class Zufallszahlengenerator {
    
        
    public abstract int nextInt();
    public abstract int[] getArray(int anzahl);
}
