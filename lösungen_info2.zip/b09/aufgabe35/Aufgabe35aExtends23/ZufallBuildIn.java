/*
 * Created on 05.05.2004
 *
 * 
 */
import java.util.Random;

/**
 * @author julianhartmann
 *
 * 
 */
public class ZufallBuildIn extends Zufallszahlengenerator {

    
    /*
     * private variablen
     */
    
    private Random random;
    
    public ZufallBuildIn() {
        random = new Random();
    }
    
    public ZufallBuildIn(int seed){
    	random = new Random(seed);
    }
    
    //hier wird der eingebaute Generator verwendet
    public int nextInt() {
        return random.nextInt(100);
    }
	public int[] getArray(int anzahl){
		int[] back = new int[anzahl];
		for (int i=0; i< anzahl; i++){
			back[i] = this.nextInt();
		}
		return back;
	}

}
