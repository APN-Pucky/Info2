/*
 * DEQueue.java
 *
 * Created on 24. Juni 2004, 16:21
 */

// package poldi.tutor;

/** Die Klasse Aufgabe28 enthaelt die Methoden zur Realisierung
 * einer double-ended-queue mit Hilfe eines zirkulaeren Puffers.
 *
 * @author David Ullrich
 */
public class DEQueue {
    
    private int left = 1;
    private int right = 0;
    private Object[] a;
    private int StdBufferSize = 23;
    
    /** 
     * Erzeugt eine DEQUE der Gr��e 23.
     */
    public DEQueue() { a = new Object[StdBufferSize]; }
    
    /**
     * Erzeugt eine DEQUE variabler Gr��e.
     * Ist die �bergebene Gr��e kleiner als 5 wird eine DEQUE der Gr��e 23
     * erzeugt.
     * @param size   Gr��e
     */
    public DEQueue(int size) {
        if (size>4) a = new Object[size];
        else a = new Object[StdBufferSize];
    }
    
    /**
     * Fuegt ein Element am "linken" Ende an, wenn noch Platz ist.
     * @param elem  das einzufuegende Element
     */
    public void enqueueLeft(Object elem) {
        if (isFull()) System.out.println("Puffer ist voll!");
        else {
            a[left] = elem;
            left = (left + 1) % a.length;
        }
    }
    
    /**
     * Fuegt ein Element am "rechten" Ende an, wenn noch Platz ist.
     * @param elem  das einzufuegende Element
     */
    public void enqueueRight(Object elem) {
        if (isFull()) System.out.println("Puffer ist voll!");
        else {
            a[right] = elem;
            if (right == 0) right = a.length - 1;
            else right--;
        }
    }
    
    /** 
     * Entfernt das Element am linken Ende der DEQueue, wenn eins existiert.
     */
    public void dequeueLeft() {
        if (isEmpty()) System.out.println("Puffer ist leer!");
        else {
            if (left == 0) left = a.length - 1;
            else left--;
        }
    }
    
    /**
     * Entfernt das Element am rechten Ende der DEQueue, wenn eins existiert.
     */
    public void dequeueRight() {
        if (isEmpty()) System.out.println("Puffer ist leer!");
        else right = (right + 1) % a.length;
    }
    
    /**
     * Testet ob der Puffer voll ist.
     * @return  <code>true</code>, wenn voll, sonst <code>false</code>
     */
    public boolean isFull() { return ((left + 1) % a.length == right); }
    
    /**
     * Testet ob der Puffer leer ist.
     * @return  <code>true</code>, wenn voll, sonst <code>false</code>
     */
    public boolean isEmpty() { return (((right + 1) % a.length) == left); }
    
    /** 
     * Gibt das Element am linken Ende der DEQueue zur�ck, wenn die DEQueue
     * nicht leer ist.
     * @return  das Objekt, bzw. <code>null</code>, wenn DEQueue leer
     */
    public Object front() {
        if (isEmpty()) return null;
        else return (left == 0) ? a[(a.length - 1)] : a[left - 1];
    }
    
    /**
     * Gibt das Element am rechten Ende der DEQueue zur�ck, wenn die DEQueue
     * nicht leer ist.
     * @return  das Objekt, bzw. <code>null</code>, wenn DEQueue leer
     */
    public Object back() {
        if (isEmpty()) return null;
        else return a[(right + 1) % a.length];
    }
}