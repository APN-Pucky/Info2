/*
 * DEQueueTest.java
 *
 * Created on 24. Juni 2004, 18:32
 */

//package poldi.tutor;

/**
 * @author  Michael Poldner
 */
public class DEQueueTest {
    
    DEQueue d = null;
    
    /** Creates a new instance of DEQueueTest */
    public DEQueueTest() {
        d = new DEQueue(5);
    }
    
    
    // Test
    public void run() {
        System.out.println("DEQueue der Gr��e 5 erzeugt.");
        System.out.println("");
        
        // teste rechts rein, rechts raus
        d.enqueueRight(new Integer(7));
        if (d.isEmpty()==false) System.out.println("Test ok");
        else System.out.println("Test failed");
        d.dequeueRight();
        if (d.isEmpty()==true) System.out.println("Test ok");
        else System.out.println("Test failed");
        
        // teste rechts rein, links raus
        d.enqueueRight(new Integer(7));
        d.dequeueLeft();
        if (d.isEmpty()==true) System.out.println("Test ok");
        else System.out.println("Test failed");

        // teste links rein, rechts raus
        d.enqueueLeft(new Integer(7));
        if (d.isEmpty()==false) System.out.println("Test ok");
        else System.out.println("Test failed");
        d.dequeueRight();
        if (d.isEmpty()==true) System.out.println("Test ok");
        else System.out.println("Test failed");

        // teste links rein, links raus
        d.enqueueLeft(new Integer(7));
        d.dequeueLeft();
        if (d.isEmpty()==true) System.out.println("Test ok");
        else System.out.println("Test failed");

        // nach drei Elementen ist Queue voll
        d.enqueueLeft("1");
        d.enqueueLeft("2");
        d.enqueueLeft("3");
        if (d.isEmpty()==false) System.out.println("Test ok");
        else System.out.println("Test failed");
        if (d.isFull()==true) System.out.println("Test ok");
        else System.out.println("Test failed");
        
        // Teste front und back
        if ( ((String) d.front()).equals("3") ) System.out.println("Test ok");
        else System.out.println("Test failed");
        if ( ((String) d.back()).equals("1") ) System.out.println("Test ok");
        else System.out.println("Test failed");
    }
    

    public static void main(String[] args) {
        DEQueueTest test = new DEQueueTest();
        test.run();
    }
}
