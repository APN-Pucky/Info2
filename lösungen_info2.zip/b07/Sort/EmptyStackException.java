/**
 * EmptyStackException definiert die Exception, die geworfen wird,
 * wenn eine unerlaubte Operation fuer einen leeren Stack aufgerufen
 * wird.
 * @version 1.0
 * @author Klaus Hinrichs
 * @see Stack
 * @see ArrayStack
 * @see ListStack
 */

import java.lang.*;

public class EmptyStackException extends RuntimeException {

     // Konstruktor
 
     /**
      * Der Konstruktor erzeugt eine neue EmptyStackException.
      */
     public EmptyStackException() { }


} // class EmptyStackException