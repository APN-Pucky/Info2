import java.lang.*;public class Pair<T1, T2>{private T1 e1;
private T2 e2;public Pair(T1 e1, T2 e2) {    this.e1 = e1;
    this.e2 = e2;}public T1 first() {    return this.e1;}public T2 rest() {    return this.e2;}} // class Pair