/**
  * Die Klasse ListNode implementiert die Knoten einer Liste.
  * @version 2.0
  * @author Klaus Hinrichs
  */

public class ListNode<E> {
 
	// private Attribute
	private ListNode<E> next = null;  // Referenz auf den naechsten Listenknoten
	private E element = null;         // Referenz auf Datenelement
 
	// Konstruktoren
 
	/**
	* Der Konstruktor erzeugt einen neuen Listenknoten und
	* fuegt (Referenz auf) Datenelement in den Knoten ein.
	*/
	public ListNode() { }

	/**
	* Der Konstruktor erzeugt einen neuen Listenknoten und
	* fuegt ein Datenelement in den Knoten ein.
	* @param element (Referenz auf) Datenelement
	*/
	public ListNode(E element) {
		this.element = element;
	};

	// public Methoden

	/**
	 * Setzt (Referenz auf den) Nachfolgerknoten.
	 * @param  next  Nachfolgerknoten
	 */
	public void setNextNode(ListNode<E> next) {
		this.next = next;
	}

	/**
	 * Gibt (Referenz auf den) Nachfolgerknoten zurueck.
	 * @return  Nachfolgerknoten
     */
	public ListNode<E> getNextNode() {
		return next;
	}

	/**
	 * Fuegt (Referenz auf) Datenelement in Knoten ein.
	 * @param  element  (Referenz auf) einzufuegendes Datenelement
	 */
	public void setData(E element) {
		this.element = element;
	}

	/**
	 * Gibt (Referenz auf) im Knoten gespeichertes Datenelement zurueck.
	 * @return  (Referenz auf) Datenelement
	 */
	public E getData() {
		return element;
	}

} // class ListNode
 

 