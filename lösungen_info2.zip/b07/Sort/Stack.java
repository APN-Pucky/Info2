 /**
 * Stack definiert ein interface fuer den ADT Stack.
 * @version 2.0
 * @author Klaus Hinrichs
 * @see ArrayStack
 * @see ListStack
 */

public interface Stack<E> {

    /**
	 * Legt ein Element auf den Stack.
	 * @param  element  einzufuegendes Element
	 */
    public void push(E element);

    /**
	 * Liefert "true" zurueck, falls der Stack leer ist, sonst "false".
	 * @return  true, falls der Stack leer ist, sonst false
	 */
    public boolean isempty();

    /**
	 * Liefert das oberste Element des Stacks zurueck. Ist der Stack leer,
	 * so wird eine EmptyStackException geworfen.
	 * @return  das oberste Element des Stacks
	 * @throw  EmptyStackException - falls der Stack leer ist
	 */
    public E top() throws EmptyStackException;

    /**
	 * Entfernt das oberste Element vom Stack. Ist der Stack leer,
	 * so wird eine EmptyStackException geworfen.
	 * @throw  EmptyStackException - falls der Stack leer ist
	 */
    public void pop() throws EmptyStackException;

} // interface Stack