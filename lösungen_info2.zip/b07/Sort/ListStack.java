/**
 * Die Klasse ListStack implementiert das Interface Stack
 * durch eine verkettete Liste.
 * @version 2.0
 * @author Klaus Hinrichs
 * @see Stack
 */

public class ListStack<E> implements Stack<E> {

	// private Attribute
	private ListNode<E> top = null;     // Referenz auf das top Element
 
	// Konstruktoren
 
	/**
	 * Der Konstruktor erzeugt einen neuen Stack.
	 * @see Stack
	 */
	public ListStack() { }

	// public Methoden

	/**
	 * Legt das Element "elem" (eine Objektreferenz) auf den Stack.
	 * @param  elem  einzufuegendes Element
	 * @see Stack
	 */
	public void push(E element) {
		ListNode<E> temp = new ListNode<E>();
		temp.setData(element);
		temp.setNextNode(top);
		top = temp;
    }

    /**
     * Liefert "true" zurueck, falls der Stack leer ist, sonst "false".
	 * @return  true, falls der Stack leer ist, sonst false
	 * @see Stack
	 */
    public boolean isempty() {
		return (top == null);
	}

    /**
	 * Liefert das oberste Element des Stacks zurueck. Falls dieses nicht
	 * vorhanden ist, wird die null Referenz zurueckgegeben.
     * @return  das oberste Element des Stacks, falls vorhanden, sonst null
	 * @see Stack
	 */
	public E top() throws EmptyStackException {
		if (isempty()) {
			throw new EmptyStackException();
		} else
			return top.getData();
    }

    /**
	 * Entfernt das oberste Element vom Stack, falls vorhanden.
	 * @see Stack
	 */
	public void pop() throws EmptyStackException {
		if (isempty())
			throw new EmptyStackException();
		else
			top = top.getNextNode();
	}
 
} // class ListStack

 