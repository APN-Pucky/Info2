package Blatt_03;

import java.util.ArrayList;

public class RISC_Maschine {
	
	
	public static void main (String[] args){
		
		int[] a = new int[]{11,22,33}; 
		int tmp = 0;
		
		RISC_Maschine r = new RISC_Maschine();
		
		tmp = r.encode(a);
		System.out.println("Encoded: " + tmp);
		
		for(int i=0;i<3;i++){
			System.out.print("Value " + (i+1) + ": " + a[i] + ((i==2) ? "\n" : " "));
		}
		
		a = r.decode(tmp);
		
		for(int i=0;i<3;i++){
			System.out.print("Value " + (i+1) + ": " + a[i] + ((i==2) ? "\n" : " "));
		}
		
		System.out.println("\nTest Aufgabe - Teil 1");
		
		a = r.decode(222000123);
		
		for(int i=0;i<3;i++){
			System.out.print("Value " + (i+1) + ": " + a[i] + ((i==2) ? "\n" : " "));
		}
		
		tmp = r.encode(a);
		System.out.println("Encoded: " + tmp);
		
		
		System.out.println("\nTest Aufgabe - Teil 2");
		
		tmp = r.encode(new int[]{123,124,125});
		System.out.println("Encoded: " + tmp);
		
		a = r.decode(tmp);

		for(int i=0;i<3;i++){
			System.out.print("Value " + (i+1) + ": " + a[i] + ((i==2) ? "\n" : " "));
		}
		
		System.out.println("\nTest Negative:\n");
		
		tmp = r.encode(new int[]{11,22,-33});
		System.out.println("Encoded: " + tmp);
		
		a = r.decode(tmp);

		for(int i=0;i<3;i++){
			System.out.print("Value " + (i+1) + ": " + a[i] + ((i==2) ? "\n" : " "));
		}
		
	}
	
	
	/**
	 * Decoded eine Int Zahl zu ihren dre Ursprungswerten
	 * @param internalFormat verschluesselter Integer
	 * @return entschluesselte drei Werte
	 */
	public int[] decode(int internalFormat){
		
		int[] array = new int[3];
		
		int j=0, k=0;
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		//schrieben aller Ziffern in eine ArrayList
		int current = internalFormat;
		while (current != 0) {
		    int digit = current % 10; // aktuell am weitesten rechts stehende Stelle
		    list.add(digit);
		    
		    current /= 10;
		}

		
		
		for(Integer a : list){
			//prüfen auf Vorzichen wenn die vordersten 3 Zeichen
			if(a == list.get(list.size()-4)){
				//Vorzeichen auslesen
				for(int i=0;i<3;i++){
					if( list.get(list.size()-3+i) == 2){
						array[2-i] *= -1;
					}
				}
				break;
				
			}else{
				/*
				 * Hier werden die einzelnen Ziffern fuer die jeweiligen Zahlen extrahiert.
				 * Diese werden aus der Arraylist entnommen und mit 10^j multipliziert um die 
				 * korrekte Stelle zu gewährleisten
				 */
				k=3*j;
				array[2] += list.get(k+2) * Math.pow(10, j);
				array[1] += list.get(k+1) * Math.pow(10, j);			
				array[0] += list.get(k)   * Math.pow(10, j);
			}

			j++;
		}
				
		
		return array;
		
		
	}
	
	/**
	 * Encdoed drei Werte in einen Integer, indem diese Hintereinander geschrieben werden
	 * @param threeIntegersArray zu verschluesselndes Array
	 * @return	verschluesselter Wert
	 */
	public int encode(int[] threeIntegersArray){
		
		if(threeIntegersArray == null)
			throw new IllegalArgumentException("Es wurde null uebergeben");

		//bestimmen der laensten Zahl. (negativ oder positiv)
		//und Bestimmung der Vorzeichen
		int max = 0;
		int[] vz = new int[3];
		for (int i=0;i<3;i++){
			int tmp=0;
			if(threeIntegersArray[i] < 0){
				tmp = (-1) * threeIntegersArray[i];
				threeIntegersArray[i] *= -1;
				vz[i] = 2;
			}else{
				tmp = threeIntegersArray[i];
				vz[i] = 1;
			}
			
			if(tmp > max)
				max = tmp;
		}
		
		int ret=0;
		int j=0;
		while (max>0){
			
			/*
			 * errechnen der jeweiligen aufzuaddierenden Ziffer.Hierzu wird immer die niedrigste Ziffer
			 * der Zahlen genommen und hintereinander in die resultierende geschrieben (*1, *10, *100)
			 * 
			 */
			ret += ( (int)(threeIntegersArray[0]/(Math.pow(10, j)) )%10 )		*1		*	Math.pow(1000, j);			
			ret += ( (int)(threeIntegersArray[1]/(Math.pow(10, j)) )%10 )		*10 	* 	Math.pow(1000, j);
			ret += ( (int)(threeIntegersArray[2]/(Math.pow(10, j)) )%10 )		*100	* 	Math.pow(1000, j);
			
			j++;	
			max /= 10;
		}
		
		ret += vz[0]*Math.pow(1000, j)*100 + vz[1]*Math.pow(1000, j) * 10 + vz[2]*Math.pow(1000, j) ;
		
				
		return ret;
		
		
	}
	
	

}
